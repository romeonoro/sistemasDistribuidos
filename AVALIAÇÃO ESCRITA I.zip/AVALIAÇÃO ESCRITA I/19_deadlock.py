import threading
import time

recurso1 = threading.Lock()
recurso2 = threading.Lock()


def thread1():
    print("Thread 1 tentando adquirir recurso 1")
    with recurso1:
        print("Thread 1 adquiriu recurso 1")
        time.sleep(1)
        
        print("Thread 1 tentando adquirir recurso 2")
        with recurso2:
            print("Thread 1 adquiriu recurso 2")
    
    print("Thread 1 finalizada\n")


def thread2():
    print("Thread 2 tentando adquirir recurso 2")
    with recurso2:
        print("Thread 2 adquiriu recurso 2")
        time.sleep(1)
        
        print("Thread 2 tentando adquirir recurso 1")
        with recurso1:
            print("Thread 2 adquiriu recurso 1")
    
    print("Thread 2 finalizada\n")


# cria
t1 = threading.Thread(target=thread1)
t2 = threading.Thread(target=thread2)

# inicia
t1.start()
t2.start()

# espera a thread terminar
t1.join()
t2.join()

print("fim!")
