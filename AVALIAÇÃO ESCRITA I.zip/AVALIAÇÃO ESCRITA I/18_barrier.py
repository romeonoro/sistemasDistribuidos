import threading
import time
import random

# cria barreira
barreira = threading.Barrier(4)

def tarefa(nome):
    print(f"{nome} - Iniciando a primeira parte ")
    time.sleep(random.uniform(0.5, 2))  # simula tempo variável de execução
    print(f"{nome} - Terminou a primeira parte, aguardando outras threads...")
    
    barreira.wait()
    
    print(f"{nome} - Iniciando a segunda parte ")

# cria
threads = []
for i in range(1, 5):
    t = threading.Thread(target=tarefa, args=(f"Thread {i}",))
    threads.append(t)
    t.start()

# espera a thread terminar
for t in threads:
    t.join()

print("fim!")
