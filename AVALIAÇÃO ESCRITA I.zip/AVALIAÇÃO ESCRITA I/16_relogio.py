import threading
import time
import random

# relógios lógicos iniciais
clock_p1 = 0
clock_p2 = 0

# Lock para sincronização de prints e clocks
lock = threading.Lock()

def processo1():
    global clock_p1, clock_p2
    for i in range(5):
        clock_p1 += 1
        with lock:
            print(f"P1 - Evento local {i+1}, clock: {clock_p1}")
        
        # envio mensagem para P2
        time.sleep(random.uniform(0.1, 0.5))  # atraso simulado
        clock_p1 += 1
        with lock:
            print(f"P1 -> P2 envia mensagem, clock: {clock_p1}")
            # atualiza clock do P2 ao receber
            clock_p2 = max(clock_p2, clock_p1) + 1
            print(f"P2 recebe mensagem, clock atualizado: {clock_p2}")

def processo2():
    global clock_p1, clock_p2
    for i in range(5):
        clock_p2 += 1
        with lock:
            print(f"P2 - Evento local {i+1}, clock: {clock_p2}")
        
        # envio de mensagem para P1
        time.sleep(random.uniform(0.1, 0.5))  # atraso simulado
        clock_p2 += 1
        with lock:
            print(f"P2 -> P1 envia mensagem, clock: {clock_p2}")
            # atualiza clock do P1 ao receber
            clock_p1 = max(clock_p1, clock_p2) + 1
            print(f"P1 recebe mensagem, clock atualizado: {clock_p1}")

# cria
t1 = threading.Thread(target=processo1)
t2 = threading.Thread(target=processo2)

# inicia
t1.start()
t2.start()

# espera a thread terminar
t1.join()
t2.join()

print("fim!")
