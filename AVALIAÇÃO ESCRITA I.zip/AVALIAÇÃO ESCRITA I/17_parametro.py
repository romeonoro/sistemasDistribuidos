import threading

numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

resultado = 0

# cria lock
lock = threading.Lock()

def soma_lista(lista):
    global resultado
    total = sum(lista)
    # atualiza
    with lock:
        resultado = total

# cria
t = threading.Thread(target=soma_lista, args=(numeros,))

t.start() # inicia
t.join() # espera a thread terminar

print(f"soma da lista: {resultado}")
