import threading

contador = 0

# cria lock
lock = threading.Lock()

def incrementar():
    global contador
    for _ in range(100000):
        with lock:
            contador += 1  # operação atômica 

# cria
t1 = threading.Thread(target=incrementar)
t2 = threading.Thread(target=incrementar)

# inicia
t1.start()
t2.start()

# espera a thread terminar
t1.join()
t2.join()

print(f"valor final do contador: {contador}")
