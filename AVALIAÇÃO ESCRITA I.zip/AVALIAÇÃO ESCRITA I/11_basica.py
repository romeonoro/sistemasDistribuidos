import threading
import time

def imprimir_pares():
    for i in range(0, 21, 2):
        print(f"Par: {i} ")
        time.sleep(0.2)

def imprimir_impares():
    for i in range(1, 20, 2):
        print(f"Impar: {i} ")
        time.sleep(0.2)
        
# cria
t1 = threading.Thread(target=imprimir_pares)
t2 = threading.Thread(target=imprimir_impares)

# inicia
t1.start()
t2.start()

# espera a thread terminar
t1.join()
t2.join()

print("fim!")
