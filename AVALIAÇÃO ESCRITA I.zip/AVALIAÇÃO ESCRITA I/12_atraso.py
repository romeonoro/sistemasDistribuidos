import threading
import time

def imprimir_nome(nome, intervalo):
    for i in range(3):  
        print(f"{nome} - execucao {i+1}")
        time.sleep(intervalo)

# cria com tempos diferentes
t1 = threading.Thread(target=imprimir_nome, args=("Thread 1", 1))
t2 = threading.Thread(target=imprimir_nome, args=("Thread 2", 2))
t3 = threading.Thread(target=imprimir_nome, args=("Thread 3", 3))

# inicia
t1.start()
t2.start()
t3.start()

# espera a thread terminar
t1.join()
t2.join()
t3.join()

print("fim!")
