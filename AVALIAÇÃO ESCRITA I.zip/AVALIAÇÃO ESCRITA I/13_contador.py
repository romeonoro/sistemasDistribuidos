import threading

contador = 0

def incrementar():
    global contador
    for _ in range(100000):
        contador += 1 # operação não atômica (lê valor, incrementa e escreve novo)

# cria
t1 = threading.Thread(target=incrementar)
t2 = threading.Thread(target=incrementar)

# inicia
t1.start()
t2.start()

# espera a thread terminar
t1.join()
t2.join()

print(f"valor final do contador: {contador}")
