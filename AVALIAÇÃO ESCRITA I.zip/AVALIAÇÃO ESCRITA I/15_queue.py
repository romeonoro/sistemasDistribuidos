import threading
import queue
import time
import random

fila = queue.Queue(maxsize=3)

def produtor():
    for i in range(10):
        item = f"Item {i} "
        fila.put(item)  # adiciona na fila (bloqueia se estiver cheia)
        print(f"Produtor produziu: {item} ")
        time.sleep(random.uniform(0.1, 0.5))  # tempo aleatório de produção

def consumidor():
    for i in range(10):
        item = fila.get()  # remove da fila (bloqueia se estiver vazia)
        print(f"Consumidor consumiu: {item} ")
        time.sleep(random.uniform(0.2, 0.6))  # tempo aleatório de consumo
        fila.task_done()  # sinaliza que o item foi processado

# cria
t_produtor = threading.Thread(target=produtor)
t_consumidor = threading.Thread(target=consumidor)

# inicia
t_produtor.start()
t_consumidor.start()

# espera a thread terminar
t_produtor.join()
t_consumidor.join()

print("fim!")
